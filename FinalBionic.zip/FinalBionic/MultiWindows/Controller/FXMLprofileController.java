/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import Model.Userdata;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author Hud
 */

// deklarasi untuk objek di fxml   
public class FXMLprofileController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;

    @FXML
    private TextField address;

    @FXML
    private Button article;

    @FXML
    private Button catalog;

    @FXML
    private Button home;

    @FXML
    private Button login;

    @FXML
    private Button logout;

    @FXML
    private TextField name;

    @FXML
    private Button order;

    @FXML
    private TextField password;

    @FXML
    private TextField phone;

    @FXML
    private Button poin;

    @FXML
    void Article(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpilihanArtikel.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Order(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/order.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Catalog(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/katalog.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Home(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLhome.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Login(ActionEvent event) {

    }

    @FXML
    void LogOut(ActionEvent event) throws IOException  {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Poin(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpoinforuser.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void textField(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Get the logged-in user data from the login controller
        Userdata loggedInUser = FXMLloginController.getLoggedInUser();

        // Set the text fields with the logged-in user data
        name.setText(loggedInUser.getUsername());
        address.setText(loggedInUser.getAddress());
        phone.setText(loggedInUser.getPhone());
        password.setText(loggedInUser.getPassword());
    }  
}
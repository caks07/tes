/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.ResourceBundle;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.stage.Stage;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import java.io.FileOutputStream;
import java.util.ArrayList;
import com.thoughtworks.xstream.XStream;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;


import Model.Pembelian;


public class FXMLorderController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;


    @FXML
    private Button Article1;

    @FXML
    private Button Catalog2;

    @FXML
    private Button Home1;

    @FXML
    private Button Order1;

    @FXML
    private Button Poin1;

    @FXML
    private Button hapus;

    @FXML
    private Button hapusSemua;

      @FXML
    private Button profile1;

      @FXML
    private Button logout1;

    @FXML
    private TableView<Pembelian> tabelorder;
    
    @FXML
    private TableColumn<Pembelian, String> jenisColumn;
    
    @FXML
    private TableColumn<Pembelian, Integer> jumlahColumn;
    
    @FXML
    private TableColumn<Pembelian, Integer> totalColumn;
    
    @FXML
    private TableColumn<Pembelian, Integer> poinColumn;

    @FXML
    private TableColumn<Pembelian, String> ukuranColumn;

    @FXML
void hapusSemuaData(ActionEvent event) {
    // Konfirmasi penghapusan semua data
    Alert confirmationAlert = new Alert(AlertType.CONFIRMATION, "Apakah Anda yakin ingin menghapus semua data?", ButtonType.YES, ButtonType.NO);
    confirmationAlert.showAndWait();
    
    if (confirmationAlert.getResult() == ButtonType.YES) {
        // Menghapus semua item dari tabel
        tabelorder.getItems().clear();
        
        // Menghapus semua data dari XML
        hapusSemuaPembelianFromXML();
        
        // Menampilkan notifikasi berhasil dihapus
        Alert successAlert = new Alert(AlertType.INFORMATION, "Semua data berhasil dihapus.", ButtonType.OK);
        successAlert.showAndWait();
    }
}

private void hapusSemuaPembelianFromXML() {
    List<Pembelian> pembelianList = new ArrayList<>();
    
    // Menyimpan ulang data kosong ke XML
    try {
        FileOutputStream fileOutputStream = new FileOutputStream("DataPembelian.xml");
        XStream xstream = new XStream(new StaxDriver());
        xstream.alias("list", List.class);
        xstream.alias("Pembelian", Pembelian.class);
        xstream.addPermission(AnyTypePermission.ANY);
        xstream.toXML(pembelianList, fileOutputStream);
        fileOutputStream.close();
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    @FXML
void hapusData(ActionEvent event) {
    // Mendapatkan model seleksi tabel
    TableViewSelectionModel<Pembelian> selectionModel = tabelorder.getSelectionModel();
    
    // Memeriksa apakah ada baris yang dipilih
    if (!selectionModel.isEmpty()) {
        // Mendapatkan item yang dipilih
        Pembelian pembelian = selectionModel.getSelectedItem();
        
        // Konfirmasi penghapusan
        Alert confirmationAlert = new Alert(AlertType.CONFIRMATION, "Apakah Anda yakin ingin menghapus data ini?", ButtonType.YES, ButtonType.NO);
        confirmationAlert.showAndWait();
        
        if (confirmationAlert.getResult() == ButtonType.YES) {
            // Menghapus item dari tabel
            tabelorder.getItems().remove(pembelian);
            
            // Menghapus item dari XML
            hapusPembelianFromXML(pembelian);
            
            // Menampilkan notifikasi berhasil dihapus
            Alert successAlert = new Alert(AlertType.INFORMATION, "Data berhasil dihapus.", ButtonType.OK);
            successAlert.showAndWait();
        }
    } else {
        // Menampilkan pesan jika tidak ada baris yang dipilih
        Alert errorAlert = new Alert(AlertType.ERROR, "Tidak ada data yang dipilih.", ButtonType.OK);
        errorAlert.showAndWait();
    }
}

private void hapusPembelianFromXML(Pembelian pembelian) {
    List<Pembelian> pembelianList = readPembelianFromXML("DataPembelian.xml");
    
    // Mencari dan menghapus item yang sesuai
    pembelianList.removeIf(p -> p.equals(pembelian));
    
    // Menyimpan ulang data ke XML
    try {
        FileOutputStream fileOutputStream = new FileOutputStream("DataPembelian.xml");
        XStream xstream = new XStream(new StaxDriver());
        xstream.alias("list", List.class);
        xstream.alias("Pembelian", Pembelian.class);
        xstream.addPermission(AnyTypePermission.ANY);
        xstream.toXML(pembelianList, fileOutputStream);
        fileOutputStream.close();
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    
    private ObservableList<Pembelian> pembelianList = FXCollections.observableArrayList();
    

    private ObservableList<Pembelian> readPembelianFromXML(String filePath) {
        List<Pembelian> pembelianList = new ArrayList<>();
    
        try {
            FileInputStream fileInputStream = new FileInputStream(filePath);
            XStream xstream = new XStream(new StaxDriver());
            xstream.alias("list", List.class);
            xstream.alias("Pembelian", Pembelian.class);
            xstream.addPermission(AnyTypePermission.ANY);
            pembelianList = (List<Pembelian>) xstream.fromXML(fileInputStream);
            fileInputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    
        // Mengonversi List menjadi ObservableList
        ObservableList<Pembelian> observablePembelianList = FXCollections.observableArrayList(pembelianList);
    
        return observablePembelianList;
    }

    
    

    @FXML
    void Article2(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpilihanArtikel.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }

    @FXML
    void profile1(ActionEvent event) throws IOException {
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLprofile.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
  
    }

    @FXML
    void Catalog2(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/katalog.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
  
    }

    @FXML
    void Home2(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLhome.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
   
    }

    @FXML
    void Order2(ActionEvent event) throws IOException{

    }

    @FXML
    void Poin2(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpoinforuser.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
   
    }

    @FXML
    void logout2(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
  
    }

    

    @Override
    public void initialize (URL url, ResourceBundle rb) {
            jenisColumn.setCellValueFactory(cellData -> cellData.getValue().getJenisProperty());
    jumlahColumn.setCellValueFactory(cellData -> cellData.getValue().getJumlahProperty().asObject());
    totalColumn.setCellValueFactory(cellData -> cellData.getValue().getTotalProperty().asObject());
    poinColumn.setCellValueFactory(cellData -> cellData.getValue().getPoinProperty().asObject());
    ukuranColumn.setCellValueFactory(cellData -> cellData.getValue().getUkuranProperty());

    pembelianList.addAll(readPembelianFromXML("DataPembelian.xml"));
    hapus.setOnAction(this::hapusData);
    hapusSemua.setOnAction(this::hapusSemuaData);



    tabelorder.setItems(pembelianList);
        pembelianList = FXCollections.observableArrayList();
    }
}
package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FXMLDeliveryController implements Initializable{

    private Parent root;
    private Scene scene;
    private Stage stage;

    @FXML
    private Button Profil;

    @FXML
    private TextField TFresi;

    @FXML
    private TableView<DeliveryData> TVDelivry;

    @FXML
    private TableColumn<DeliveryData, String> alamat;

    @FXML
    private Button article;

    @FXML
    private Button catalog;

    @FXML
    private Button delivery;

    @FXML
    private Button edit;

    @FXML
    private Button save;


    @FXML
    private TableColumn<DeliveryData, String> harga;

    @FXML
    private TableColumn<DeliveryData, String> jumlah;

    @FXML
    private Button logout;

    @FXML
    private TableColumn<DeliveryData, String> noPemesanan;

    @FXML
    private TableColumn<DeliveryData, String> resiPengiriman;

    @FXML
    private Button salesData;

    @FXML
    private TableColumn<DeliveryData, String> tanggal;

    @FXML
    private TableColumn<DeliveryData, String> ukuran;

    @FXML
    private Button userdata;

    @FXML
    private TableColumn<DeliveryData, String> username;

    @FXML
    private ObservableList<DeliveryData> deliveryDataList;


    @FXML
    void article(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/editartikel.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void catalog(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLcatalogPengelola.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void logout(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void salesdata(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLsales.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void userdata(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLUserdata.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }


    @Override
   public void initialize(URL url, ResourceBundle rb) {
        deliveryDataList = FXCollections.observableArrayList(
                new DeliveryData("Harga 1", "Jumlah 1", "Alamat 1", "No Pemesanan 1", "Tanggal 1", "Ukuran 1", "Username 1", ""),
                new DeliveryData("Harga 2", "Jumlah 2", "Alamat 2", "No Pemesanan 2", "Tanggal 2", "Ukuran 2", "Username 2", ""),
                new DeliveryData(" ", " ", " ", " ", " ", " ", " ", "")
        );

        harga.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getHarga()));
        jumlah.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getJumlah()));
        alamat.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAlamat()));
        noPemesanan.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNoPemesanan()));
        tanggal.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTanggal()));
        ukuran.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getUkuran()));
        username.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getUsername()));
        resiPengiriman.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getResiPengiriman()));

        TVDelivry.setItems(deliveryDataList);
    }

    @FXML
    private void handleEditButton(ActionEvent event) {
        DeliveryData selectedData = TVDelivry.getSelectionModel().getSelectedItem();
        if (selectedData != null) {
            selectedData.setResiPengiriman(TFresi.getText());
        }
    }

    @FXML
    private void handleSaveButton(ActionEvent event) {
        DeliveryData selectedData = TVDelivry.getSelectionModel().getSelectedItem();
        if (selectedData != null) {
            selectedData.setResiPengiriman(TFresi.getText());
            TVDelivry.refresh();
        }
        TFresi.clear();
    }
}


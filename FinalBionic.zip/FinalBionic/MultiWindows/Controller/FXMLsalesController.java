package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.Initializable;


public class FXMLsalesController implements Initializable{

    private Parent root;
    private Scene scene;
    private Stage stage;


    private Model model;

    @FXML
    private Button Buttonhapus;

    @FXML
    private Button Buttontambah;

    @FXML
    private BarChart<String, Integer> city;

    @FXML
    private TextField indexField;

    @FXML
    private TextField kotaField;

    @FXML
    private TextField valueField;

    @FXML
    private Label label;

    @FXML
    private Button edit;

    @FXML
    private Button simpan;
    
    @FXML
    private Button article;

    @FXML
    private Button catalog;

    @FXML
    private Button delivery;

    @FXML
    private Button logout;

    @FXML
    private Button userdata;

    @FXML
    void handleButtonHapus(ActionEvent event) {
        int index = Integer.parseInt(indexField.getText());
        model.removeData(index);
        indexField.clear();
    }

    @FXML
    void handleButtonTambah(ActionEvent event) {
        String name = kotaField.getText();
        int value = Integer.parseInt(valueField.getText());
        model.addData(name, value);
        kotaField.clear();
        valueField.clear();
    }

    @FXML
    void logout(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void catalog(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLcatalogPengelola.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void userData(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLUserdata.fxml.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void article(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/editartikel.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void delivery(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLdelivery.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    
    public void setModel(Model model) {
        this.model = model;
        city.getData().add(model.getSeries());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}

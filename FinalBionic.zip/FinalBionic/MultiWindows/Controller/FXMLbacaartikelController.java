/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;


import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class FXMLbacaartikelController implements Initializable {

    public void setData(String judulArtikel, String deskripsiArtikel, String imagePath) {
        judul.setText(judulArtikel);
        isi.setText(deskripsiArtikel);

        if (imagePath != null) {
            Image image = new Image(imagePath);
            upload.setImage(image);
        }
    }

    @FXML
    private Button back;

    @FXML
    private ImageView upload;

    @FXML
    private Label judul;
    
    @FXML
    private Label isi;

    @FXML
    private void goToeditArtikel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/editartikel.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    @Override
    public void initialize (URL url, ResourceBundle rb) {
        //TODO
    }
}

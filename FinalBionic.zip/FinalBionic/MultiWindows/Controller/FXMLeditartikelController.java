/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
/**
 *
 * @author raja
 */

// deklarasi untuk objek di fxml

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class FXMLeditartikelController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;
    private String imagePath;

    @FXML
    private ImageView gambartambah;

    @FXML
    private Button editartikelsales;

    @FXML
    private Button editartikelcatalog;

    @FXML
    private Button editartikelorder;

    @FXML
    private Button editartikelpoin;

    @FXML
    private Button editartikellogout;

    @FXML
    private TextField editartikeljudul;

    @FXML
    private TextField editartikeldeskripsi;

    @FXML
    private Button editartikeltitiktiga;

    @FXML
    private Button editartikelplus;

    @FXML
    private Button editartikelupload;
    
    @FXML
    private Button uploadButton;

    @FXML
    private Label fileNameLabel;

    @FXML
    private void catalog(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLcatalogPengelola.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void salesdata(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLsales.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void logout(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
      }

    @FXML
    void delivery(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLdelivery.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
      }

    @FXML
    void userData(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLcatalogPengelola.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
      }
  

    @FXML
    private void handleUploadButtonAction(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Pilih Gambar");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Gambar", "*.png", "*.jpg", "*.gif"));

        Stage stage = (Stage) uploadButton.getScene().getWindow();
        File file = fileChooser.showOpenDialog(stage);

        if (file != null) {
            Image image = new Image(file.toURI().toString());
            gambartambah.setImage(image);

            // Simpan path gambar yang diupload dalam variabel imagePath
            imagePath = file.toURI().toString();

            // Tampilkan label dengan nama file yang diupload
            fileNameLabel.setText(file.getName());
        } else {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Peringatan");
            alert.setHeaderText(null);
            alert.setContentText("Tidak ada file yang dipilih!");
            alert.showAndWait();
        }
    }

    @FXML
    private void goToBacaArtikel(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/bacaartikel.fxml"));
        Parent root = loader.load();
        FXMLbacaartikelController bacaArtikelController = loader.getController();
        bacaArtikelController.setData(editartikeljudul.getText(), editartikeldeskripsi.getText(), imagePath);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
}
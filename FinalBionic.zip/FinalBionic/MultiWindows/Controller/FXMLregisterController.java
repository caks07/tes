/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.binding.IntegerExpression;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import Model.Userdata;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import Model.Userdata;

/**
 *
 * @author Hud
 */

// deklarasi untuk objek di fxml   
public class FXMLregisterController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;

    @FXML
    private TextField address;

    @FXML
    private Button back;

    @FXML
    private TextField confirm;

    @FXML
    private Button create;

    @FXML
    private TextField name;

    @FXML
    private TextField password;

    @FXML
    private TextField phone;

    @FXML
    private Label pesaneror;

    private List<Userdata> readUserdataFromXML(String filename) {
      List<Userdata> userList = new ArrayList<>();
  
      try {
          FileInputStream fileInputStream = new FileInputStream(filename);
          XStream xstream = new XStream(new StaxDriver());
          xstream.alias("list", List.class);
          xstream.alias("Userdata", Userdata.class);
          xstream.addPermission(AnyTypePermission.ANY);
          userList = (List<Userdata>) xstream.fromXML(fileInputStream);
          fileInputStream.close();
      } catch (FileNotFoundException e) {
          // File not found, return an empty list
      } catch (IOException e) {
          e.printStackTrace();
      }
  
      return userList;
  }
  


    @FXML
    void Back(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Create(ActionEvent event) throws IOException {
        String enteredUsername = name.getText();
        String enteredPassword = password.getText();
        String enteredConfirm = confirm.getText();

        if (enteredUsername.isEmpty() || enteredConfirm.isEmpty()) {
            pesaneror.setText("Lengkapi data terlebih dahulu!");
            pesaneror.setVisible(true);
        } else if (!enteredPassword.equals(enteredConfirm)) {
            pesaneror.setText("Confirm password tidak sesuai!");
            pesaneror.setVisible(true);
        } else {
            Userdata newUser = new Userdata(enteredUsername, enteredPassword, address.getText(), phone.getText());
            saveUserdata(newUser);

            root = FXMLLoader.load(getClass().getResource("/FXML/FXMLlogin.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            pesaneror.setVisible(false);
        }
    }

    private void saveUserdata(Userdata newUser) {
        List<Userdata> userList = readUserdataFromXML("DataUser.xml");
        userList.add(newUser);

        try {
            FileOutputStream fileOutputStream = new FileOutputStream("DataUser.xml");
            XStream xstream = new XStream(new StaxDriver());
            xstream.alias("list", List.class);
            xstream.alias("Userdata", Userdata.class);
            xstream.addPermission(AnyTypePermission.ANY);
            xstream.toXML(userList, fileOutputStream);
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        pesaneror.setVisible(false);
    }
}
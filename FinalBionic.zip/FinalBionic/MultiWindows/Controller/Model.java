package Controller;

import javafx.scene.chart.XYChart;

public class Model {

    private XYChart.Series<String, Integer> series;

    public Model() {
        series = new XYChart.Series<>();
        initData();
    }

    public XYChart.Series<String, Integer> getSeries() {
        return series;
    }

    private void initData() {
        series.getData().add(new XYChart.Data<>("january", 100));
        series.getData().add(new XYChart.Data<>("ferbuary", 50));
        series.getData().add(new XYChart.Data<>("maret", 150));
    }

    public void addData(String name, int value) {
        series.getData().add(new XYChart.Data<>(name, value));
    }

    public void removeData(int index) {
        series.getData().remove(index);
    }
}

package Controller;

import javafx.beans.property.SimpleStringProperty;

public class DeliveryData {
    private final SimpleStringProperty harga;
    private final SimpleStringProperty jumlah;
    private final SimpleStringProperty noPemesanan;
    private final SimpleStringProperty tanggal;
    private final SimpleStringProperty ukuran;
    private final SimpleStringProperty username;
    private final SimpleStringProperty alamat;
    private final SimpleStringProperty resiPengiriman;

    public DeliveryData(String harga, String jumlah, String alamat, String noPemesanan, String tanggal, String ukuran, String username, String resiPengiriman) {
        this.harga = new SimpleStringProperty(harga);
        this.jumlah = new SimpleStringProperty(jumlah);
        this.noPemesanan = new SimpleStringProperty(noPemesanan);
        this.tanggal = new SimpleStringProperty(tanggal);
        this.ukuran = new SimpleStringProperty(ukuran);
        this.username = new SimpleStringProperty(username);
        this.alamat = new SimpleStringProperty(alamat);
        this.resiPengiriman = new SimpleStringProperty(resiPengiriman);
    }

    public String getHarga() {
        return harga.get();
    }

    public String getJumlah() {
        return jumlah.get();
    }

    public String getNoPemesanan() {
        return noPemesanan.get();
    }

    public String getAlamat() {
        return alamat.get();
    }

    public String getTanggal() {
        return tanggal.get();
    }

    public String getUkuran() {
        return ukuran.get();
    }

    public String getUsername() {
        return username.get();
    }

    public String getResiPengiriman() {
        return resiPengiriman.get();
    }

    public void setResiPengiriman(String resiPengiriman) {
        this.resiPengiriman.set(resiPengiriman);
    }
}

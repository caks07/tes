/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Controller.FXMLregisterController;


import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import Model.Userdata;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import Model.Userdata;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;


/**
 *
 * @author Hud
 */

// deklarasi untuk objek di fxml   
public class FXMLloginController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;

    @FXML
    private Label pesaneror;

    @FXML
    private Button back;

    @FXML
    private Button login;

    @FXML
    private TextField password;

    @FXML
    private Button register;

    @FXML
    private TextField username;

    private static Userdata loggedInUser;

    @FXML
    void textField(ActionEvent event) {    

    }

    private List<Userdata> readUserdataFromXML(String filename) {
      List<Userdata> userList = new ArrayList<>();
  
      try {
          FileInputStream fileInputStream = new FileInputStream(filename);
          XStream xstream = new XStream(new StaxDriver());
          xstream.alias("list", List.class);
          xstream.alias("Userdata", Userdata.class);
          xstream.addPermission(AnyTypePermission.ANY);
          userList = (List<Userdata>) xstream.fromXML(fileInputStream);
          fileInputStream.close();
      } catch (FileNotFoundException e) {
          // File not found, return an empty list
      } catch (IOException e) {
          e.printStackTrace();
      }
  
      return userList;
  }
  

  @FXML
  void Login(ActionEvent event) throws IOException {
      String enteredUsername = username.getText();
      String enteredPassword = password.getText();
      if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
          pesaneror.setText("Username dan password harus diisi!");
          pesaneror.setVisible(true);
      } else {
          boolean isValidUser = validateUser(enteredUsername, enteredPassword);

          if (isValidUser) {
              // Set the logged-in user data
              loggedInUser = getUserByUsername(enteredUsername);

              root = FXMLLoader.load(getClass().getResource("/FXML/FXMLhome.fxml"));
              stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
              scene = new Scene(root);
              stage.setScene(scene);
              stage.show();
              pesaneror.setVisible(false);
          } else {
              pesaneror.setText("Username atau password tidak sesuai!");
              pesaneror.setVisible(true);
          }
      }
  }

  private Userdata getUserByUsername(String username) {
    List<Userdata> userList = readUserdataFromXML("DataUser.xml");

    for (Userdata user : userList) {
        if (user.getUsername().equals(username)) {
            return user;
        }
    }

    return null;
}

public static Userdata getLoggedInUser() {
  return loggedInUser;
}


    private boolean validateUser(String username, String password) {
      List<Userdata> userList = readUserdataFromXML("DataUser.xml");

      for (Userdata user : userList) {
          if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
              return true; // Username dan password sesuai dengan data yang tersimpan
          }
      }

      return false; // Username atau password tidak sesuai dengan data yang tersimpan
  }

    @FXML
    void Register(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLregister.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Back(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        pesaneror.setVisible(false);
    }
}
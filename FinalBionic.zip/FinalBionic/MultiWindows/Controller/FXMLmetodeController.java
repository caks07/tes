/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class FXMLmetodeController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;

    @FXML
    private Button back;

    @FXML
    private Button choose1;

    @FXML
    private Button choose2;

    @FXML
    private Button choose3;

    @FXML
    private Button choose4;

    @FXML
    private Button choose5;

    @FXML
    private Button choose6;

    @FXML
    private Button choose7;

    @FXML
    private Button choose8;

    @FXML
    private Button ChoiceBig;

    @FXML
    private Button ChoiceMedium;

    @FXML
    private Button ChoiceSmall;

    @FXML
    void Back(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/katalog.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void choose1(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/peringatan.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }
    @FXML
    void choose2(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/peringatan.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }
    @FXML
    void choose3(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/peringatan.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }
    @FXML
    void choose4(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/peringatan.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }
    @FXML
    void choose5(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/peringatan.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }
    @FXML
    void choose6(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/peringatan.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }
    @FXML
    void choose7(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/peringatan.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }
    @FXML
    void choose8(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/peringatan.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }

    @Override
    public void initialize (URL url, ResourceBundle rb) {
        //TODO
    }
}

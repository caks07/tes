package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import Model.Userdata;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;


public class FXMLUserdataController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;

        @FXML
    private Button hapus;

        @FXML
    private Button hapusSemua;
    @FXML
    private Button catalog;

    @FXML
    private Button articel;

    @FXML
    private Button salesdata;

    @FXML
    private Button delivery;

    @FXML
    private Button userdata;

    @FXML
    private Button logout;

    @FXML
    private TextField txtField1;

    @FXML
    private TextField txtField2;

    @FXML
    private TextField txtField3;

    @FXML
    private TextField txtField4;

    @FXML
    private TableView<Userdata> tv;

    @FXML
    private TableColumn<Userdata, String> tc1;

    @FXML
    private TableColumn<Userdata, String> tc2;

    @FXML
    private TableColumn<Userdata, String> tc3;

    @FXML
    private TableColumn<Userdata, String> tc4;

    private ObservableList<Userdata> data;

    private List<Userdata> readUserdataFromXML(String filename) {
      List<Userdata> userList = new ArrayList<>();
  
      try {
          FileInputStream fileInputStream = new FileInputStream(filename);
          XStream xstream = new XStream(new StaxDriver());
          xstream.alias("list", List.class);
          xstream.alias("Userdata", Userdata.class);
          xstream.addPermission(AnyTypePermission.ANY);
          userList = (List<Userdata>) xstream.fromXML(fileInputStream);
          fileInputStream.close();
      } catch (FileNotFoundException e) {
          // File not found, return an empty list
      } catch (IOException e) {
          e.printStackTrace();
      }
  
      return userList;
  }
  



    @FXML
    private void catalog(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLcatalogPengelola.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void article(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/editartikel.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void salesdata(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLsales.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void delivery(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLdelivery.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void logout(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
      }

      @Override
public void initialize(URL url, ResourceBundle rb) {
    try {
        // Inisialisasi kolom
        tc1.setCellValueFactory(new PropertyValueFactory<>("username"));
        tc2.setCellValueFactory(new PropertyValueFactory<>("phone"));
        tc3.setCellValueFactory(new PropertyValueFactory<>("address"));
        tc4.setCellValueFactory(new PropertyValueFactory<>("password"));

        // Memuat data dari file XML
        List<Userdata> userList = readUserdataFromXML("DataUser.xml");

        // Mengkonversi List menjadi ObservableList
        data = FXCollections.observableArrayList(userList);

        // Menampilkan data ke dalam tabel
        tv.setItems(data);
    } catch (Exception e) {
        e.printStackTrace();
    }
}

      
        @FXML
    void hapusData(ActionEvent event) {
        TableViewSelectionModel<Userdata> selectionModel = tv.getSelectionModel();

        if (!selectionModel.isEmpty()) {
            Userdata userdata = selectionModel.getSelectedItem();

            Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION,
                    "Apakah Anda yakin ingin menghapus data ini?", ButtonType.YES, ButtonType.NO);
            confirmationAlert.showAndWait();

            if (confirmationAlert.getResult() == ButtonType.YES) {
                tv.getItems().remove(userdata);
                hapusDataUser(userdata);
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Data berhasil dihapus.", ButtonType.OK);
                successAlert.showAndWait();
            }
        } else {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Tidak ada data yang dipilih.", ButtonType.OK);
            errorAlert.showAndWait();
        }
    }

    private void hapusDataUser(Userdata userdata) {
        List<Userdata> userList = readUserdataFromXML("DataUser.xml");
        userList.removeIf(u -> u.getUsername().equals(userdata.getUsername()));

        try {
            FileOutputStream fileOutputStream = new FileOutputStream("DataUser.xml");
            XStream xstream = new XStream(new StaxDriver());
            xstream.alias("list", List.class);
            xstream.alias("Userdata", Userdata.class);
            xstream.addPermission(AnyTypePermission.ANY);
            xstream.toXML(userList, fileOutputStream);
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void hapusSemuaData(ActionEvent event) {
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION,
                "Apakah Anda yakin ingin menghapus semua data?", ButtonType.YES, ButtonType.NO);
        confirmationAlert.showAndWait();

        if (confirmationAlert.getResult() == ButtonType.YES) {
            tv.getItems().clear();
            hapusSemuaDataUser();
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Semua data berhasil dihapus.", ButtonType.OK);
            successAlert.showAndWait();
        }
    }

    private void hapusSemuaDataUser() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("DataUser.xml");
            XStream xstream = new XStream(new StaxDriver());
            xstream.alias("list", List.class);
            xstream.alias("Userdata", Userdata.class);
            xstream.addPermission(AnyTypePermission.ANY);
            xstream.toXML(new ArrayList<>(), fileOutputStream);
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


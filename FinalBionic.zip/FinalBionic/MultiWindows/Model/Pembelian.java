package Model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class Pembelian {
       private StringProperty jenis;
    private IntegerProperty jumlah;
    private IntegerProperty total;
    private IntegerProperty poin;
    private StringProperty ukuran;

    public Pembelian(String jenis, int jumlah, int total, int poin, String ukuran) {
        this.jenis = new SimpleStringProperty(jenis);
        this.jumlah = new SimpleIntegerProperty(jumlah);
        this.total = new SimpleIntegerProperty(total);
        this.poin = new SimpleIntegerProperty(poin);
        this.ukuran = new SimpleStringProperty(ukuran);
    }


    public StringProperty getJenisProperty() {
        return jenis;
    }

    public IntegerProperty getJumlahProperty() {
        return jumlah;
    }

    public IntegerProperty getTotalProperty() {
        return total;
    }

    public IntegerProperty getPoinProperty() {
        return poin;
    }

    public void setJenis(String jenis) {
        this.jenis.set(jenis);
    }

    public void setJumlah(int jumlah) {
        this.jumlah.set(jumlah);
    }

    public void setTotal(int total) {
        this.total.set(total);
    }

    public void setPoin(int poin) {
        this.poin.set(poin);
    }

    public StringProperty getUkuranProperty() {
        return ukuran;
    }

    public String getUkuran() {
        return ukuran.get();
    }

    public void setUkuran(String ukuran) {
        this.ukuran.set(ukuran);
    }
}
